//
//  ViewController.swift
//  Native_WebRTC
//
//  Created by vignesh on 16/12/19.
//  Copyright © 2019 vignesh. All rights reserved.
//

import UIKit
import Foundation

class ViewController: UIViewController {
    
    @IBOutlet weak var loginIndicator: UIActivityIndicatorView!
    
    @IBOutlet weak var callerBtn: UIButton!
    
    @IBOutlet weak var calleeBtn: UIButton!
    
    @IBAction func callerBtnAction(_ sender: Any) {
        
        self.isCaller = true
        
        let userList:NSMutableArray = self.getUserArr()

        self.popUPView(userList: userList)
    }
    
    @IBAction func calleeBtnAction(_ sender: Any) {
    
        self.isCaller = false
        
        let userList:NSMutableArray = self.getUserArr()

        let fromUser: String = MessageUtility.getFromUser()

        userList.remove(fromUser)
        
        self.popUPView(userList: userList)
    }
    
    @IBAction func enterToWEBRTCAction(_ sender: Any) {
         
        print("WelCome to WEBRTC")
        
        self.loginIndicator.isHidden = true

        let fromUser: String = MessageUtility.getFromUser()
        
        let toUser: String = MessageUtility.getToUser()
        
        if fromUser.count > 0 && toUser.count > 0 {
           
            if isValidEmail(emailStr: fromUser) && isValidEmail(emailStr: toUser) {
                
                let fromUserArr = fromUser.components(separatedBy: "@")
                
                let toUserArr = toUser.components(separatedBy: "@")

                if fromUserArr.count == 2 && toUserArr.count == 2 {
                    
                    let storyBoard  = UIStoryboard.init(name: "Main", bundle:nil)

                    let webRTCController  = storyBoard.instantiateViewController(withIdentifier:"WebRTCController") as! WebRTCController
                                                           
                    self.present(webRTCController, animated: true, completion: nil)
                    
                } else {
                    
                    let alertController  = UIAlertController.init(title: "Error", message: "Please Select User", preferredStyle: .alert)
                    
                    let alert = UIAlertAction.init(title: "Done", style: .cancel) { (alert) in
                                           
                    }
                    
                    alertController.addAction(alert)
                    
                    self.present(alertController, animated: true, completion: nil)
                    
                }
                
            }else{
                
                let alertController  = UIAlertController.init(title: "Error", message: "Please Select User", preferredStyle: .alert)
                                          
                let alert = UIAlertAction.init(title: "Done", style: .cancel) { (alert) in
                                                                 
                }
                
                alertController.addAction(alert)
                                          
                self.present(alertController, animated: true, completion: nil)
                
            }
            
        }
          
    }
    
    var isCaller:Bool = false

    let userArr = NSMutableArray()
      
    var popOverController  : UIPopoverPresentationController?

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
                
        self.initUserArr()

        self.loginIndicator.isHidden = true
    }
    
    func initUserArr() {
        
        if userArr.count > 0 {
            userArr.removeAllObjects()
        }
        
        let noOfUser:Int = 10
        
        for id in 1...noOfUser {
            let userName = "user\(id)@gmail.com"
            userArr.add(userName)
        }
    }
    
    func getUserArr() -> NSMutableArray {
        
        let copyUserArr:NSMutableArray = NSMutableArray()
        
        if userArr.count > 0 {
            copyUserArr.addObjects(from: userArr as! [Any])
        }
        
        return copyUserArr
    }
    
    func popUPView(userList:NSMutableArray) {
        
        let storyBoard  = UIStoryboard.init(name: "Main", bundle: nil)

        let popOverView  = storyBoard.instantiateViewController(withIdentifier: "PopOverViewController") as! PopOverViewController
        
        popOverView.modalPresentationStyle = .popover
        
        if let popover = popOverView.popoverPresentationController {
            
            popover.sourceView = self.view
            
            popover.permittedArrowDirections = UIPopoverArrowDirection.init(rawValue: 0)
            
            popover.sourceRect = CGRect(x: self.view.bounds.width/2, y: self.view.bounds.height/2, width: 100, height: 200)
            
            popOverView.preferredContentSize = CGSize(width: 50, height: 100)
            
            popOverView.titleStr = "Select User"
          
            popOverView.listArr = userList
            
            popOverView.popOverViewControllerDelegate = self
            
            popover.delegate = self as? UIPopoverPresentationControllerDelegate
            
          }

          self.present(popOverView, animated: true, completion: nil)
        
    }
    
    func adaptivePresentationStyle(for controller: UIPresentationController) -> UIModalPresentationStyle {

       return UIModalPresentationStyle.none
    }
    
     func isValidEmail(emailStr:String) -> Bool {
        
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"

        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        
        return emailPred.evaluate(with: emailStr)
    }

}

extension ViewController :PopOverViewControllerDelegate{
    
    func popoOverSelectedListArr(userName: String) {
        
        if isCaller {
            
            MessageUtility.setFromUser(fromUser: userName)
                        
            callerBtn.setTitle(userName, for: .normal)
            
        }else{
            
            MessageUtility.setToUser(toUser: userName)
            
            calleeBtn.setTitle(userName, for: .normal)

        }
        
    }
    
}

