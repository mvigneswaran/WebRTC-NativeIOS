//
//  JSONConverter.swift
//  Native_WebRTC
//
//  Created by vignesh on 18/12/19.
//  Copyright © 2019 vignesh. All rights reserved.
//

import Foundation

struct MessageUtility {
    
    static let login_SignalType:String = "login"
    static let offer_SignalType:String = "offer"
    static let answer_SignalType:String = "answer"
    static let candidate_SignlType:String = "candidate"
    static let leave_SignalType:String = "leave"
    
    static func sessionObjToSessionDic(sessionObj:SessionDescription) -> NSMutableDictionary {
        
        let sessionDic:NSMutableDictionary = NSMutableDictionary()
        
        sessionDic.setValue("session", forKey: "msgType")
        
        sessionDic.setValue(sessionObj.sdp, forKey: "sdp")
        
        switch sessionObj.type {
        case .offer:
            sessionDic.setValue("offer", forKey: "type")
        case .answer:
            sessionDic.setValue("answer", forKey: "type")
        case .prAnswer:
            sessionDic.setValue("prAnswer", forKey: "type")
        }
        
        return sessionDic
    }
    
    static func sessionDicToSessionObj(sessionDic:Any) -> SessionDescription {
        
        let sessionObj:SessionDescription = SessionDescription(from: sessionDic)
        
        return sessionObj
    }
    
    static func candidateObjToCandidateDic(candidateObj:IceCandidate) -> NSMutableDictionary {
        
        let candidateDic:NSMutableDictionary = NSMutableDictionary()
        
        candidateDic.setValue("candidate", forKey: "msgType")

        candidateDic.setValue(candidateObj.sdp, forKey: "sdp")
        
        candidateDic.setValue(String.init(candidateObj.sdpMLineIndex), forKey: "sdpMLineIndex")
        
        candidateDic.setValue(candidateObj.sdpMid, forKey: "sdpMid")

        return candidateDic
    }
    
    static func candidateDicToCandidateObj(candidateDic:Any) -> IceCandidate {
        
        let candidateObj:IceCandidate = IceCandidate(from: candidateDic)
        
        return candidateObj
    }
    
    static func jsonString(jsonObj:Any) -> String {
        
        var jsonStr: String = ""
        
        if let data = try? JSONSerialization.data(withJSONObject: jsonObj, options: .prettyPrinted) {
            jsonStr = String(bytes: data, encoding: .utf8)!
            return jsonStr
        }
        
        return jsonStr
    }
    
    static func jsonObject(jsonStr:String) -> Any {
        
        var jsonObj: Any = {}
        
        let data = jsonStr.data(using: .utf8)
        
        if let obj = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments) {
            jsonObj = obj
            return jsonObj
        }
        return jsonObj
    }
    
    //Signaling Events
    
    static func loginMsg(fromUser:String) -> NSMutableDictionary {
        
        let loginDic:NSMutableDictionary = NSMutableDictionary()
        
        loginDic.setValue("other", forKey: "msgType")
        loginDic.setValue(self.login_SignalType, forKey: "signalType")
        loginDic.setValue(fromUser, forKey: "fromUser")
        
        return loginDic
    }
    
    static func offerMsg(messageDic:NSMutableDictionary, fromUser:NSString, toUser:NSString) -> NSMutableDictionary {
        
        if messageDic.count > 0 {
            messageDic.setValue(self.offer_SignalType, forKey: "signalType")
            messageDic.setValue(fromUser, forKey: "fromUser")
            messageDic.setValue(toUser, forKey: "toUser")
            return messageDic
        }else{
            return NSMutableDictionary()
        }
    }
    
    static func answerMsg(messageDic:NSMutableDictionary, fromUser:NSString, toUser:NSString) -> NSMutableDictionary {
        
        if messageDic.count > 0 {
            messageDic.setValue(self.answer_SignalType, forKey: "signalType")
            messageDic.setValue(fromUser, forKey: "fromUser")
            messageDic.setValue(toUser, forKey: "toUser")
            return messageDic
        }else{
            return NSMutableDictionary()
        }
    }
    
    static func candidateMsg(messageDic:NSMutableDictionary, fromUser:NSString, toUser:NSString) -> NSMutableDictionary {
        
        if messageDic.count > 0 {
            messageDic.setValue(self.candidate_SignlType, forKey: "signalType")
            messageDic.setValue(fromUser, forKey: "fromUser")
            messageDic.setValue(toUser, forKey: "toUser")
            return messageDic
        }else{
            return NSMutableDictionary()
        }
    }
    
    static func leaveMsg(fromUser:NSString, toUser:NSString) -> NSMutableDictionary {
        
        let messageDic:NSMutableDictionary = NSMutableDictionary()

        messageDic.setValue("other", forKey: "msgType")
        messageDic.setValue(self.leave_SignalType, forKey: "signalType")
        messageDic.setValue(fromUser, forKey: "fromUser")
        messageDic.setValue(toUser, forKey: "toUser")
        return messageDic
    }
    
    //User Store
    
    static func setFromUser(fromUser:String) {
        let userStore:UserDefaults = UserDefaults()
        userStore.set(fromUser, forKey: "fromUser")
    }
    
    static func getFromUser() -> String {
        let userStore:UserDefaults = UserDefaults()
        if let fromUser:String = userStore.string(forKey: "fromUser"){
            return fromUser
        }else{
            return ""
        }
    }
    
    static func setToUser(toUser:String) {
        let userStore:UserDefaults = UserDefaults()
        userStore.set(toUser, forKey: "toUser")
    }
    
    static func getToUser() -> String {
        let userStore:UserDefaults = UserDefaults()
        if let toUser:String = userStore.string(forKey: "toUser"){
            return toUser
        }else{
            return ""
        }
      
    }
    
}
