//
//  SignalClient.swift
//  WebRTC
//
//  Created by Stasel on 20/05/2018.
//  Copyright © 2018 Stasel. All rights reserved.
//

import Foundation
import WebRTC

protocol SignalClientDelegate: class {
    func signalClientDidConnect(_ signalClient: SignalingClient)
    func signalClientDidDisconnect(_ signalClient: SignalingClient)
    
    func signalClient(_ signalClient: SignalingClient, didReceiveSignal signalMsg: Any)
    func signalClient(_ signalClient: SignalingClient, didReceiveRemoteSdp sdp: RTCSessionDescription, message signalMsg: Any)
    func signalClient(_ signalClient: SignalingClient, didReceiveCandidate candidate: RTCIceCandidate, message signalMsg: Any)
}

final class SignalingClient {
    
    private let decoder = JSONDecoder()
    private let encoder = JSONEncoder()
    private let webSocket: WebSocketProvider
    var delegate: SignalClientDelegate?
    
    init(webSocket: WebSocketProvider) {
        self.webSocket = webSocket
    }
    
    func connect() {
        self.webSocket.delegate = self
        self.webSocket.connect()
    }
    
    func disconnect() {
        self.webSocket.delegate = self
        self.webSocket.disconnect()
    }
    
    func send(sdp rtcSdp: RTCSessionDescription, from fromUser:String, to toUser:String) {
        
        let sessionObj = SessionDescription(from: rtcSdp)
        
        let sessionDic = MessageUtility.sessionObjToSessionDic(sessionObj: sessionObj)
        
        let sessionType:String = sessionDic["type"] as! String
        
        if sessionType == "offer" {
            let updatedSessionDic = MessageUtility.offerMsg(messageDic: sessionDic, fromUser: fromUser as NSString, toUser: toUser as NSString)
            
            let sessionMessage = MessageUtility.jsonString(jsonObj: updatedSessionDic)
            
            self.webSocket.send(jsonStr: sessionMessage)
        }else{
            let updatedSessionDic = MessageUtility.answerMsg(messageDic: sessionDic, fromUser: fromUser as NSString, toUser: toUser as NSString)
            
            let sessionMessage = MessageUtility.jsonString(jsonObj: updatedSessionDic)
            
            self.webSocket.send(jsonStr: sessionMessage)
        }
        
    }
    
    func send(candidate rtcIceCandidate: RTCIceCandidate, from fromUser:String, to toUser:String) {
        
        let candidateObj = IceCandidate(from: rtcIceCandidate)
        
        let candidateDic = MessageUtility.candidateObjToCandidateDic(candidateObj: candidateObj)
        
        let updatedCandidateDic = MessageUtility.candidateMsg(messageDic: candidateDic, fromUser: fromUser as NSString, toUser: toUser as NSString)
            
        let candidateMessage = MessageUtility.jsonString(jsonObj: updatedCandidateDic)
        
        self.webSocket.send(jsonStr: candidateMessage)
    }
    
    func sendRegister(regUser:String) {
        
        let loginDic = MessageUtility.loginMsg(fromUser: regUser)
        
        let loginMessage = MessageUtility.jsonString(jsonObj: loginDic)
        
        print("Login-Request:",loginMessage)
        
        self.webSocket.send(jsonStr: loginMessage)
    }
    
    func sendHangUp(fromUser:String, toUser:String) {
        
        let leaveSignalDic = MessageUtility.leaveMsg(fromUser: fromUser as NSString, toUser: toUser as NSString)
        
        let leaveSignalMessage = MessageUtility.jsonString(jsonObj: leaveSignalDic)
        
        print("Leave-Request:", leaveSignalMessage)
        
        self.webSocket.send(jsonStr: leaveSignalMessage)
    }
    
    func send(messageDic:NSMutableDictionary, fromUser:NSString, toUser:NSString) {
        
        
    }
}


extension SignalingClient: WebSocketProviderDelegate {
    func webSocketDidConnect(_ webSocket: WebSocketProvider) {
        self.delegate?.signalClientDidConnect(self)
    }
    
    func webSocketDidDisconnect(_ webSocket: WebSocketProvider) {
        self.delegate?.signalClientDidDisconnect(self)
        
        // try to reconnect every two seconds
        DispatchQueue.global().asyncAfter(deadline: .now() + 2) {
            debugPrint("Trying to reconnect to signaling server...")
            self.webSocket.connect()
        }
    }
    
    func webSocket(_ webSocket: WebSocketProvider, didReceiveData jsonStr: String) {
                
        let messageObj = MessageUtility.jsonObject(jsonStr: jsonStr) as! [String:String]
        
        print(messageObj["signalType"] as Any, "\nResponse:\n",jsonStr)
        
        switch messageObj["msgType"] {
        case "session":
            let sessionDescription:SessionDescription = MessageUtility.sessionDicToSessionObj(sessionDic: messageObj)
            self.delegate?.signalClient(self, didReceiveRemoteSdp: sessionDescription.rtcSessionDescription, message: messageObj)
        case "candidate":
            let iceCandidate:IceCandidate = MessageUtility.candidateDicToCandidateObj(candidateDic: messageObj)
            self.delegate?.signalClient(self, didReceiveCandidate: iceCandidate.rtcIceCandidate, message: messageObj)
        case "other":
            self.delegate?.signalClient(self, didReceiveSignal: messageObj)
        default:break
        }
        
    }
}
