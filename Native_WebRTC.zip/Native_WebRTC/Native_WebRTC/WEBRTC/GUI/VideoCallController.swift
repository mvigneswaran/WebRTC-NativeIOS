//
//  VideoCallController.swift
//  Native_WebRTC
//
//  Created by vignesh on 16/12/19.
//  Copyright © 2019 vignesh. All rights reserved.
//

import Foundation
import UIKit
import WebRTC

class VideoCallController: UIViewController {
    
    var webRTCClient: WebRTCClient?
    
    private let config = Config.default
    
    var isCaller: Bool = false

    var delegate : VideoCallControllerdelegate?
    
    @IBOutlet private var localVideoView: UIView?
    
    @IBOutlet private weak var speakerButton: UIButton?

    @IBOutlet private weak var muteButton: UIButton?

    @IBOutlet weak var hangUpBtn: UIButton!

    @IBAction private func speakerOnOffAction(_ sender: UIButton) {
        if self.speakerOn {
            self.webRTCClient?.speakerOff()
        }
        else {
            self.webRTCClient?.speakerOn()
        }
        self.speakerOn = !self.speakerOn
    }
    
    @IBAction private func micOnOffAction(_ sender: UIButton) {
        self.mute = !self.mute
        if self.mute {
            self.webRTCClient?.muteAudio()
        }
        else {
            self.webRTCClient?.unmuteAudio()
        }
    }
    
    @IBAction func hangUPAction(_ sender: Any) {
                
        guard (delegate?.didReceiveHangUp(sender) != nil) else {return}
    }
    
    
    
//    init(webRTCClient: WebRTCClient) {
//        self.webRTCClient = webRTCClient
//        super.init(nibName: String(describing: VideoCallController.self), bundle: Bundle.main)
//    }
//
//    @available(*, unavailable)
//    required init?(coder aDecoder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.speakerOn = false
        
        if #available(iOS 13.0, *) {
            // Using OpenGLES for the rest
            let localRenderer = RTCEAGLVideoView(frame: self.localVideoView?.frame ?? CGRect.zero)
            let remoteRenderer = RTCEAGLVideoView(frame: self.view.frame)
            
            self.webRTCClient?.startCaptureLocalVideo(renderer: localRenderer)
            self.webRTCClient?.renderRemoteVideo(to: remoteRenderer)
                  
            if let localVideoView = self.localVideoView {
                self.embedView(localRenderer, into: localVideoView)
            }
            self.embedView(remoteRenderer, into: self.view)
            self.view.sendSubviewToBack(remoteRenderer)
        }else{
            #if arch(arm64)
                // Using metal (arm64 only)
                let localRenderer = RTCMTLVideoView(frame: self.localVideoView?.frame ?? CGRect.zero)
                let remoteRenderer = RTCMTLVideoView(frame: self.view.frame)
                    localRenderer.videoContentMode = .scaleAspectFill
                    remoteRenderer.videoContentMode = .scaleAspectFill
            #else
                // Using OpenGLES for the rest
                let localRenderer = RTCEAGLVideoView(frame: self.localVideoView?.frame ?? CGRect.zero)
                let remoteRenderer = RTCEAGLVideoView(frame: self.view.frame)
            #endif
            
            self.webRTCClient?.startCaptureLocalVideo(renderer: localRenderer)
            self.webRTCClient?.renderRemoteVideo(to: remoteRenderer)
                  
            if let localVideoView = self.localVideoView {
                self.embedView(localRenderer, into: localVideoView)
            }
            self.embedView(remoteRenderer, into: self.view)
            self.view.sendSubviewToBack(remoteRenderer)
        }

      
    }
    
    //Utilities
    
    private func embedView(_ view: UIView, into containerView: UIView) {
        containerView.addSubview(view)
        view.translatesAutoresizingMaskIntoConstraints = false
        containerView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|[view]|",
                                                                    options: [],
                                                                    metrics: nil,
                                                                    views: ["view":view]))
        
        containerView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|[view]|",
                                                                    options: [],
                                                                    metrics: nil,
                                                                    views: ["view":view]))
        containerView.layoutIfNeeded()
    }
    
    private var speakerOn: Bool = false {
        didSet {
                        
            self.speakerButton?.backgroundColor = (self.speakerOn) ? UIColor.lightGray : UIColor.darkGray
            
//            let title = "Speaker: \(self.speakerOn ? "On" : "Off" )"
//            self.speakerButton?.setTitle(title, for: .normal)
        }
    }
    
    private var mute: Bool = false {
        didSet {
            
            self.muteButton?.backgroundColor = (self.mute) ? UIColor.lightGray : UIColor.darkGray
            
            
//            let title = "Mute: \(self.mute ? "on" : "off")"
//            self.muteButton?.setTitle(title, for: .normal)
        }
    }
    
}

protocol VideoCallControllerdelegate {
    
    func didReceiveHangUp(_:Any)
    
}
