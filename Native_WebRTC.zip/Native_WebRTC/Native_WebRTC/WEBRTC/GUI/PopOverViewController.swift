//
//  PopOverViewController.swift
//  Native_WebRTC
//
//  Created by sivakumar on 19/12/19.
//  Copyright © 2019 vignesh. All rights reserved.
//

import UIKit

class PopOverViewController: UIViewController {

    @IBOutlet weak var titleLbl: UILabel!
    
    @IBOutlet weak var listTbl: UITableView!
    
    var titleStr  = String()
    
    var popOverViewControllerDelegate : PopOverViewControllerDelegate? = nil
    
    var listArr  = NSArray()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

      
        titleLbl.text = titleStr
        
    }

}
extension PopOverViewController: UITableViewDataSource,UITableViewDelegate{
   
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
      
        let cell = tableView.dequeueReusableCell(withIdentifier: "listTableViewCell") as! listTableViewCell
              
        cell.lable.text = listArr[indexPath.row] as? String
        
        return cell
        
      }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
        let userName  = listArr[indexPath.row]
        
        guard ((popOverViewControllerDelegate?.popoOverSelectedListArr(userName: userName as! String)) != nil) else {return}
        
        self.dismiss(animated: true, completion:nil)
        
    }
    
}

protocol PopOverViewControllerDelegate {
    
    func  popoOverSelectedListArr(userName: String)
    
    
}
