//
//  listTableViewCell.swift
//  Native_WebRTC
//
//  Created by sivakumar on 19/12/19.
//  Copyright © 2019 vignesh. All rights reserved.
//

import UIKit

class listTableViewCell: UITableViewCell {

    @IBOutlet weak var lable: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }

}
