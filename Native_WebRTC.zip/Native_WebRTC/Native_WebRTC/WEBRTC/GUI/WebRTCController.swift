//
//  WebRTCController.swift
//  Native_WebRTC
//
//  Created by vignesh on 16/12/19.
//  Copyright © 2019 vignesh. All rights reserved.
//

import Foundation
import UIKit
import AVFoundation
import WebRTC

class WebRTCController: UIViewController {
    
    @IBOutlet weak var titileLbl: UILabel!
        
    var webRTCClient: WebRTCClient?
    
    var signalClient: SignalingClient?
    
    private let config = Config.default
    
    var isCaller: Bool = false
    
    var videoCallController:VideoCallController?
        
    @IBOutlet weak var loginStatusLabel: UILabel!
    @IBOutlet private weak var signalingStatusLabel: UILabel?
    @IBOutlet private weak var localSdpStatusLabel: UILabel?
    @IBOutlet private weak var localCandidatesLabel: UILabel?
    @IBOutlet private weak var remoteSdpStatusLabel: UILabel?
    @IBOutlet private weak var remoteCandidatesLabel: UILabel?
    @IBOutlet private weak var webRTCStatusLabel: UILabel?
    
    @IBAction private func offerVideoCallAction(_ sender: UIButton) {
               
        let fromUser: String = MessageUtility.getFromUser()
        let toUser: String = MessageUtility.getToUser()
        
        self.webRTCClient?.offer { (sdp) in
            self.hasLocalSdp = true
            self.isCaller = true
            self.signalClient?.send(sdp: sdp, from: fromUser, to: toUser)
        }
        
    }
    
    @IBAction func endVideoCallAction(_ sender: Any) {
        
         if let controller = self.videoCallController {
                  
            controller.dismiss(animated: true, completion: nil)
                  
            self.videoCallController = nil
        }
              
        let fromUser: String = MessageUtility.getFromUser()
              
        let toUser: String = MessageUtility.getToUser()
              
        self.signalClient?.sendHangUp(fromUser: fromUser, toUser: toUser)
          
        self.webRTCClient?.closePeerConnection()

        self.webRTCClient?.createPeerConnection()
              
        self.isCaller = false
        self.hasLocalSdp = false
        self.localCandidateCount = 0
        self.hasRemoteSdp = false
        self.remoteCandidateCount = 0
        
    }
    
    @IBAction func sendMessageDataAction(_ sender: UIButton) {
        
        let alert = UIAlertController(title: "Send a message to the other peer",
                                         message: "This will be transferred over WebRTC data channel",
                                         preferredStyle: .alert)
        
        alert.addTextField { (textField) in
            textField.placeholder = "Message to send"
        }
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        alert.addAction(UIAlertAction(title: "Send", style: .default, handler: { [weak self, unowned alert] _ in
            guard let dataToSend = alert.textFields?.first?.text?.data(using: .utf8) else {
                return
            }
            self?.webRTCClient?.sendData(dataToSend)
        }))
        
        self.present(alert, animated: true, completion: nil)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.logInStatus = false
        self.signalingConnected = false
        self.hasLocalSdp = false
        self.hasRemoteSdp = false
        self.localCandidateCount = 0
        self.remoteCandidateCount = 0
        self.webRTCStatusLabel?.text = "New"
        self.isCaller = false
        
        self.initClient()

        
        self.title = "WebRTC Demo"
        
        let fromUser = MessageUtility.getFromUser()
        self.titileLbl.text = fromUser

        let swipDownGerster  = UISwipeGestureRecognizer.init(target: self, action: #selector(resizeViewContronller))
        
        self.view.addGestureRecognizer(swipDownGerster)
       
    }
    
    @objc func resizeViewContronller(){
        
        self.dismiss(animated: true, completion: nil)
    }
    
    private func initClient() {

        self.webRTCClient = WebRTCClient.init(iceServers: self.config.webRTCIceServers)
        self.webRTCClient?.delegate = self
          
        self.signalClient = self.buildSignalingClient()
        self.signalClient?.delegate = self
        self.signalClient?.connect()
    }
    
    private func buildSignalingClient() -> SignalingClient {
            
        let webSocketProvider: WebSocketProvider
                    
        if #available(iOS 13.0, *) {
            webSocketProvider = NativeWebSocket(url: self.config.signalingServerUrl)
        } else {
            webSocketProvider = StarscreamWebSocket(url: self.config.signalingServerUrl)
        }
            
        return SignalingClient(webSocket: webSocketProvider)
    }
    
    //Utilities
    
    private var signalingConnected: Bool = false {
        didSet {
            DispatchQueue.main.async {
                if self.signalingConnected {
                    self.signalingStatusLabel?.text = "Connected"
                    self.signalingStatusLabel?.textColor = UIColor.green
                }
                else {
                    self.signalingStatusLabel?.text = "Not connected"
                    self.signalingStatusLabel?.textColor = UIColor.red
                }
            }
        }
    }
    
    private var logInStatus: Bool = false {
           didSet {
               DispatchQueue.main.async {
                   if self.logInStatus {
                       self.loginStatusLabel?.text = "Connected"
                       self.loginStatusLabel?.textColor = UIColor.green
                   }
                   else {
                       self.loginStatusLabel?.text = "Not connected"
                       self.loginStatusLabel?.textColor = UIColor.red
                   }
               }
           }
    }
    
    private var hasLocalSdp: Bool = false {
        didSet {
            DispatchQueue.main.async {
                self.localSdpStatusLabel?.text = self.hasLocalSdp ? "✅" : "❌"
            }
        }
    }
    
    private var localCandidateCount: Int = 0 {
        didSet {
            DispatchQueue.main.async {
                self.localCandidatesLabel?.text = "\(self.localCandidateCount)"
            }
        }
    }
    
    private var hasRemoteSdp: Bool = false {
        didSet {
            DispatchQueue.main.async {
                self.remoteSdpStatusLabel?.text = self.hasRemoteSdp ? "✅" : "❌"
            }
        }
    }
    
    private var remoteCandidateCount: Int = 0 {
        didSet {
            DispatchQueue.main.async {
                self.remoteCandidatesLabel?.text = "\(self.remoteCandidateCount)"
            }
        }
    }
    
}

extension  WebRTCController : VideoCallControllerdelegate {
    
    func didReceiveHangUp(_: Any) {
        
        if let controller = self.videoCallController {
            
            controller.dismiss(animated: true, completion: nil)
            
            self.videoCallController = nil
        }
        
        let fromUser: String = MessageUtility.getFromUser()
        
        let toUser: String = MessageUtility.getToUser()
        
        self.signalClient?.sendHangUp(fromUser: fromUser, toUser: toUser)
    
        self.webRTCClient?.closePeerConnection()

        self.webRTCClient?.createPeerConnection()
        
        self.isCaller = false
        self.hasLocalSdp = false
        self.localCandidateCount = 0
        self.hasRemoteSdp = false
        self.remoteCandidateCount = 0
        
    }
    
}

extension WebRTCController: SignalClientDelegate {
    
    func signalClientDidConnect(_ signalClient: SignalingClient) {
        self.signalingConnected = true
        
        let fromUser: String = MessageUtility.getFromUser()

        self.signalClient?.sendRegister(regUser: fromUser)
     }
     
     func signalClientDidDisconnect(_ signalClient: SignalingClient) {
         self.signalingConnected = false
     }
        
    func signalClient(_ signalClient: SignalingClient, didReceiveSignal signalMsg: Any) {
        
        DispatchQueue.main.async {
            
            let msgDic:Dictionary = signalMsg as! [String:String]
            
            if msgDic["signalType"] == MessageUtility.login_SignalType {
                
                if msgDic["success"] == "1" {
                    self.logInStatus = true
                }else{
                    self.logInStatus = false
                }
                
            } else if msgDic["signalType"] == MessageUtility.leave_SignalType {
              
                if let controller = self.videoCallController {
                    
                    controller.dismiss(animated: true, completion: nil)
                    
                    self.videoCallController = nil
                }
                       
                self.webRTCClient?.closePeerConnection()

                self.webRTCClient?.createPeerConnection()
                     
                self.isCaller = false
                self.hasLocalSdp = false
                self.localCandidateCount = 0
                self.hasRemoteSdp = false
                self.remoteCandidateCount = 0
                
            } else{
                
                
            }
            
        }
            
    }
      
    func signalClient(_ signalClient: SignalingClient, didReceiveRemoteSdp sdp: RTCSessionDescription, message signalMsg: Any) {
        
        print("Received remote sdp")
        
        DispatchQueue.main.async {
            
            let signalObj = signalMsg as! [String:String]
            
            if signalObj["signalType"] == "offer" {
                
                DispatchQueue.main.async {
                             
                    if self.isCaller == false {
                                 
                        let alert = UIAlertController(title: "WebRTC",
                                                               message: "Incoming Call",
                                                               preferredStyle: .alert)
                                 
                        alert.addAction(UIAlertAction(title: "Reject", style: .default, handler: { [weak self, unowned alert] _ in
                            
                            let fromUser: String = MessageUtility.getFromUser()
                                  
                            let toUser: String = signalObj["fromUser"]!
                                  
                            self!.signalClient?.sendHangUp(fromUser: fromUser, toUser: toUser)
                              
                            self!.webRTCClient?.closePeerConnection()

                            self!.webRTCClient?.createPeerConnection()
                                  
                            self!.isCaller = false
                            self!.hasLocalSdp = false
                            self!.localCandidateCount = 0
                            self!.hasRemoteSdp = false
                            self!.remoteCandidateCount = 0
                            
                        }))
                                 
                        alert.addAction(UIAlertAction(title: "Accept", style: .default, handler: { [weak self, unowned alert] _ in
                                    
                            if let fromUser = signalObj["fromUser"] {
                                MessageUtility.setToUser(toUser: fromUser)
                                
                                self!.webRTCClient?.set(remoteSdp: sdp) { (error) in
                                    self!.hasRemoteSdp = true
                                }
                                
                                let fromUser: String = MessageUtility.getFromUser()
                                let toUser: String = MessageUtility.getToUser()
                                        
                                self?.webRTCClient?.answer { (localSdp) in
                                    self?.hasLocalSdp = true
                                    self?.signalClient?.send(sdp: localSdp, from: fromUser, to: toUser)
                                }
                            }

                        }))
                        
                        self.present(alert, animated: true, completion: nil)
                                                 
                    }

                }
                
            }else if signalObj["signalType"] == "answer" {
                if let fromUser = signalObj["fromUser"] {
                    
                    self.webRTCClient?.set(remoteSdp: sdp) { (error) in
                         self.hasRemoteSdp = true
                    }
                }
            }
            
        }
        
    }
      
    func signalClient(_ signalClient: SignalingClient, didReceiveCandidate candidate: RTCIceCandidate, message signalMsg: Any) {
             
        print("Received remote candidate")
                 
        self.remoteCandidateCount += 1
                
        self.webRTCClient?.set(remoteCandidate: candidate)
                     
    }
    
}

extension WebRTCController: WebRTCClientDelegate {
    
    func webRTCClient(_ client: WebRTCClient, didDiscoverLocalCandidate candidate: RTCIceCandidate) {
        print("discovered local candidate")
                            
            debugPrint("Trying to send local candidate to signaling server...")
            self.localCandidateCount += 1
            
            let fromUser: String = MessageUtility.getFromUser()
            let toUser: String = MessageUtility.getToUser()
            
            self.signalClient?.send(candidate: candidate, from: fromUser, to: toUser)
        
    }
    
    func webRTCClient(_ client: WebRTCClient, didChangeConnectionState state: RTCIceConnectionState) {
        let textColor: UIColor
        switch state {
        case .connected, .completed:
            textColor = .green
        case .disconnected:
            textColor = .orange
        case .failed, .closed:
            textColor = .red
        case .new, .checking, .count:
            textColor = .black
        @unknown default:
            textColor = .black
        }
        DispatchQueue.main.async {
            
            self.webRTCStatusLabel?.text = state.description.capitalized
            self.webRTCStatusLabel?.textColor = textColor
                        
            if state.description == "connected" {
                
                let storyBoard  = UIStoryboard.init(name: "Main", bundle:nil)
                
                if self.videoCallController == nil {
                    self.videoCallController = storyBoard.instantiateViewController(withIdentifier: "VideoCallController") as? VideoCallController
                }
                
                self.videoCallController?.delegate = self
                                                                  
                self.videoCallController!.webRTCClient = self.webRTCClient
                      
                self.present(self.videoCallController!, animated: true, completion: nil)
                
            }
        }
    }
    
    func webRTCClient(_ client: WebRTCClient, didReceiveData data: Data) {
        DispatchQueue.main.async {
            let message = String(data: data, encoding: .utf8) ?? "(Binary: \(data.count) bytes)"
            let alert = UIAlertController(title: "Message from WebRTC", message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
}

